package swing;
public class Animal {

	String animalName;
	String animalDescription;
	double deviation;
	int days;
	double duration;
	String filePath;
}
