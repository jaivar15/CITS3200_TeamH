package swing;

import java.util.ArrayList;

public class Notifications {
	String animalID;
	String animalDescription;
	String alertLevel;
	
	public Notifications(String animalID, String animalDescription, String alertLevel) {
		this.animalID = animalID;
		this.animalDescription = animalDescription;
		this.alertLevel = alertLevel;
				
	}
}
